# Montse & Juan Carlos — web de boda (versión gratuita)

Esta es la primera versión estática de la web, preparada para publicarse gratis en GitHub Pages o Cloudflare Pages.

## Qué incluye
- Diseño móvil primero, romántico + elegante + toque divertido.
- Foto real de Montse y Juan Carlos como portada.
- Cuenta atrás hasta el 1 de mayo de 2027.
- Nuestra historia.
- Horario del gran día.
- Alojamiento incluido en Hotel Mas de la Sala.
- Cómo llegar + botón de Google Maps.
- Música + ADMV de Maluma.
- Confirmación de asistencia por pareja/familia.
- Preguntas de alergias, menú, alojamiento, necesidades y hasta 3 canciones.
- Galería inicial.
- Sin sección de regalos.

## Importante sobre el RSVP
La versión es estática y gratuita. El formulario está diseñado y funciona en el navegador, pero todavía no envía las respuestas a una base de datos.

El siguiente paso recomendado es conectarlo a un Google Form/Google Sheet o a un endpoint gratuito. Así las respuestas quedarán guardadas y podremos mantener el diseño exactamente igual.

## Publicación gratis
### GitHub Pages
1. Crear una cuenta en GitHub.
2. Crear un repositorio público, por ejemplo: `boda-montse-juan-carlos`.
3. Subir `index.html`, `styles.css`, `script.js` y la carpeta `assets`.
4. En Settings → Pages, seleccionar la rama `main` y carpeta `/root`.
5. GitHub dará una URL gratuita del tipo `https://TUUSUARIO.github.io/boda-montse-juan-carlos/`.

### Cloudflare Pages
También puede publicarse como sitio estático gratuito.

## Antes de imprimir el QR
Primero publicamos la web y comprobamos el móvil. Cuando tengamos la URL definitiva, generamos el QR definitivo para la invitación.

## Nota
El texto y los datos del evento se han preparado con la información que hemos definido en la conversación. La dirección del hotel y su web se han dejado como enlaces informativos.
